<?php
/*
Plugin Name: Phone Verification using iSMS
Plugin URI: https://artificerit.com/
Description: Phone number verification plugin using iSMS for WooCommerce checkout.
Version: 1.2
Author: RB Soikot
Author URI: https://artificerit.com/
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Enqueue JavaScript for sending OTP
add_action('wp_enqueue_scripts', 'enqueue_otp_script');
function enqueue_otp_script()
{
    wp_enqueue_script('otp-verification', plugin_dir_url(__FILE__) . 'otp-verification.js', array('jquery'), null, true);
    wp_localize_script('otp-verification', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}

// Add OTP field, phone number input, and send OTP button to checkout page
add_action('woocommerce_after_order_notes', 'add_phone_number_and_otp_verification');
function add_phone_number_and_otp_verification($checkout)
{
    echo '<div id="phone-verification">
            <label for="phone_number">Phone Number</label>
            <input type="text" name="phone_number" id="phone_number" placeholder="Enter your phone number" required>
            <button type="button" id="send-otp" style="padding:10px 20px;margin-top:10px;margin-bottom:10px; color:white;background-color:green;border-radius: 5px;cursor: pointer;">Send OTP</button>
            <input type="text" name="otp_code" id="otp_code" placeholder="Enter OTP">
            <span id="otp-error" style="color:red;"></span>
          </div>';
}

// Handle OTP generation and sending via AJAX
add_action('wp_ajax_send_otp', 'send_otp_callback');
add_action('wp_ajax_nopriv_send_otp', 'send_otp_callback');
function send_otp_callback()
{
    session_start();

    global $wpdb;
    $phone_number = sanitize_text_field($_POST['phone_number']);
    $table_name = $wpdb->prefix . 'verified_users';

    // Check if the phone number has already been verified
    $existing_number = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE phone_number = %s", $phone_number));
    
    if ($existing_number > 0) {
        echo json_encode(['success' => false, 'message' => 'This phone number has already been used. Please use a different number.']);
        wp_die();
    }

    // Rest of the OTP generation and sending logic
    $current_time = time();
    $last_attempt_time = isset($_SESSION['last_otp_time']) ? $_SESSION['last_otp_time'] : 0;
    $otp_attempts = isset($_SESSION['otp_attempts']) ? $_SESSION['otp_attempts'] : 0;

    $delays = [30, 60, 120]; // Delays in seconds

    // Determine the delay based on the number of attempts
    if ($otp_attempts >= count($delays)) {
        $delay = end($delays); // Use the longest delay for further attempts
    } else {
        $delay = $delays[$otp_attempts];
    }

    // Check if the user needs to wait before sending another OTP
    if ($current_time - $last_attempt_time < $delay) {
        $remaining_time = $delay - ($current_time - $last_attempt_time);
        echo json_encode(['success' => false, 'message' => "Please wait $remaining_time seconds before resending the OTP."]);
        wp_die();
    }

    // Generate and send OTP if allowed
    $otp = rand(1000, 9999); // Generate random 4-digit OTP
    $csmsId = uniqid(); // Unique ID for each SMS

    $message = "Your OTP code is: $otp";

    $response = send_sms($phone_number, $message, $csmsId);

    if ($response) {
        // Save OTP and attempts to session for later verification
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_attempts'] = $otp_attempts + 1;
        $_SESSION['last_otp_time'] = $current_time;

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send OTP.']);
    }

    wp_die();
}


// Function to send SMS using iSMS API
function send_sms($msisdn, $messageBody, $csmsId)
{
    $api_token = get_option('isms_api_token');
    $sid = get_option('isms_sid');
    $api_domain = get_option('isms_api_domain');

    $params = [
        "api_token" => $api_token,
        "sid" => $sid,
        "msisdn" => $msisdn,
        "sms" => $messageBody,
        "csms_id" => $csmsId
    ];

    $url = trim($api_domain, '/') . "/api/v3/send-sms";
    $params = json_encode($params);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($params),
        'accept:application/json'
    ));

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Validate OTP during checkout and save verified user
add_action('woocommerce_checkout_process', 'validate_otp_code');
function validate_otp_code()
{
    session_start();
    global $wpdb;
    $entered_otp = isset($_POST['otp_code']) ? sanitize_text_field($_POST['otp_code']) : '';
    $phone_number = isset($_POST['phone_number']) ? sanitize_text_field($_POST['phone_number']) : '';

    // Check if the phone number has already been verified
    $table_name = $wpdb->prefix . 'verified_users';
    $existing_number = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE phone_number = %s", $phone_number));
    
    if ($existing_number > 0) {
        wc_add_notice(__('This phone number has already been used. Please use a different number.'), 'error');
        return;
    }

    if (empty($entered_otp)) {
        wc_add_notice(__('Please enter the OTP sent to your phone.'), 'error');
    } elseif ($entered_otp != $_SESSION['otp']) {
        wc_add_notice(__('Invalid OTP. Please try again.'), 'error');
    } else {
        // Save the phone number as billing phone number
        WC()->session->set('billing_phone', $phone_number);

        // Save OTP to session for later use
        $_SESSION['otp'] = $entered_otp;

        // Check if the user is logged in
        if (is_user_logged_in()) {
            // Get current user ID
            $user_id = get_current_user_id();

            // Update billing phone in user meta
            update_user_meta($user_id, 'billing_phone', $phone_number);
        }

        // Insert verified user into database
        $wpdb->insert(
            $table_name,
            array(
                'phone_number' => $phone_number,
                'verification_date' => current_time('mysql'),
            )
        );
    }
}


// Save phone number to user profile after registration or during checkout
add_action('woocommerce_checkout_create_order', 'save_billing_phone_to_user_meta', 10, 2);
function save_billing_phone_to_user_meta($order, $data)
{
    if (is_user_logged_in()) {
        // For existing users, save the phone number to user meta
        $user_id = get_current_user_id();
        if (isset($_POST['phone_number'])) {
            update_user_meta($user_id, 'billing_phone', sanitize_text_field($_POST['phone_number']));
        }
    } else if ($order->get_customer_id()) {
        // For new users, save the phone number to user meta
        $user_id = $order->get_customer_id();
        if (isset($_POST['phone_number'])) {
            update_user_meta($user_id, 'billing_phone', sanitize_text_field($_POST['phone_number']));
        }
    }
}

// Save billing phone number in order meta
add_action('woocommerce_checkout_update_order_meta', 'save_billing_phone_number');
function save_billing_phone_number($order_id)
{
    if (isset($_POST['phone_number'])) {
        $phone_number = sanitize_text_field($_POST['phone_number']);
        update_post_meta($order_id, '_billing_phone', $phone_number);
    }
}

// Create table for verified users on plugin activation
register_activation_hook(__FILE__, 'create_verified_users_table');
function create_verified_users_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'verified_users';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        phone_number varchar(20) NOT NULL,
        verification_date datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}




// add sub menu


add_action('admin_menu', 'add_verified_users_menu');
function add_verified_users_menu()
{
    add_menu_page(
        'Verified Users',
        'Phn Verified Users',
        'manage_options',
        'verified-users',
        'display_verified_users_page'
    );

    add_submenu_page(
        'verified-users',
        'iSMS API Settings',
        'iSMS API Settings',
        'manage_options',
        'isms-api-settings',
        'isms_api_settings_page'
    );

    // Add the "Add Phone Number Manually" submenu
    add_submenu_page(
        'verified-users',
        'Add Phone Number Manually',
        'Add Phone Number Manually',
        'manage_options',
        'add-phone-number-manually',
        'add_phone_number_manually_page'
    );
}

// Existing verified users page function (unchanged)
function display_verified_users_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'verified_users';

    // Get the current page number
    $paged = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    // Set the number of results per page
    $limit = 20;
    $offset = ($paged - 1) * $limit;

    // Query to get the verified users
    $sql = $wpdb->prepare(
        "SELECT * FROM $table_name WHERE phone_number LIKE %s ORDER BY verification_date DESC LIMIT %d OFFSET %d",
        '%' . $wpdb->esc_like($search) . '%', 
        $limit, 
        $offset
    );
    $results = $wpdb->get_results($sql);

    // Count the total number of results for pagination
    $total = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE phone_number LIKE %s", '%' . $wpdb->esc_like($search) . '%'));
    $total_pages = ceil($total / $limit);

    // Display the search form
    echo '<div class="wrap"><h2>Verified Users</h2>';
    echo '<form method="get" action="">';
    echo '<input type="hidden" name="page" value="verified-users">';
    echo '<input type="search" name="s" value="' . esc_attr($search) . '">';
    echo '<input type="submit" value="Search" class="button">';
    echo '</form>';

    // Display the table of verified users
    echo '<table class="widefat fixed striped">';
    echo '<thead><tr><th>Phone Number</th><th>Verification Date</th><th>Actions</th></tr></thead>';
    echo '<tbody>';

    if ($results) {
        foreach ($results as $row) {
            echo '<tr>';
            echo '<td>' . esc_html($row->phone_number) . '</td>';
            echo '<td>' . esc_html($row->verification_date) . '</td>';
            echo '<td><a href="?page=verified-users&action=delete&id=' . esc_attr($row->id) . '">Delete</a></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="3">No verified users found.</td></tr>';
    }

    echo '</tbody>';
    echo '</table>';

      // Display pagination if there are more than 1 page of results
    if ($total_pages > 1) {
        echo '<div class="tablenav"><div class="tablenav-pages">';
        $current_url = esc_url(add_query_arg(array()));
        $page_links = paginate_links(array(
            'base' => add_query_arg('paged', '%#%', $current_url),
            'format' => '',
            'prev_text' => __('&laquo;'),
            'next_text' => __('&raquo;'),
            'total' => $total_pages,
            'current' => $paged
        ));
        echo $page_links;
        echo '</div></div>';
    }

    echo '</div>'; // Close the wrap div

    // Delete verified user
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $table_name = $wpdb->prefix . 'verified_users';
        $wpdb->delete($table_name, ['id' => $id]);
        wp_redirect(admin_url('admin.php?page=verified-users'));
        exit;
    }
}

// New function for "Add Phone Number Manually" page
function add_phone_number_manually_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'verified_users';

    // Check if the form is submitted
    if (isset($_POST['submit']) && check_admin_referer('add_phone_number_nonce')) {
        $phone_number = sanitize_text_field($_POST['phone_number']);
        $verification_date = current_time('mysql');

        // Insert the phone number into the database
        $wpdb->insert($table_name, [
            'phone_number' => $phone_number,
            'verification_date' => $verification_date
        ]);

        echo '<div class="notice notice-success is-dismissible"><p>Phone number added successfully.</p></div>';
    }

    // Display the form for adding a phone number
    echo '<div class="wrap"><h2>Add Phone Number Manually</h2>';
    echo '<form method="post" action="">';
    wp_nonce_field('add_phone_number_nonce'); // Security nonce
    echo '<table class="form-table">';
    echo '<tr><th scope="row"><label for="phone_number">Phone Number</label></th>';
    echo '<td><input name="phone_number" type="text" id="phone_number" value="" class="regular-text"></td></tr>';
    echo '</table>';
    echo '<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Add Phone Number"></p>';
    echo '</form>';
    echo '</div>';
}



function replace_placeholders($message, $order_id, $user_name) {
    $message = str_replace('{id}', $order_id, $message);
    $message = str_replace('{name}', $user_name, $message);
    return $message;
}

add_action('admin_init', 'register_isms_api_settings');
function register_isms_api_settings() {
    register_setting('isms_api_settings_group', 'isms_api_token');
    register_setting('isms_api_settings_group', 'isms_sid');
    register_setting('isms_api_settings_group', 'isms_api_domain');
}

// Add new settings for SMS notifications
add_action('admin_init', 'register_sms_notification_settings');
function register_sms_notification_settings() {
    register_setting('isms_api_settings_group', 'sms_notification_enabled');
    register_setting('isms_api_settings_group', 'sms_purchase_message');
    register_setting('isms_api_settings_group', 'sms_cancel_message');
    register_setting('isms_api_settings_group', 'sms_hold_message');
}

function isms_api_settings_page() {
    ?>
    <div class="wrap">
        <h2>iSMS API Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('isms_api_settings_group'); ?>
            <?php do_settings_sections('isms_api_settings_group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">API Token</th>
                    <td><input type="text" name="isms_api_token" value="<?php echo esc_attr(get_option('isms_api_token')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">SID</th>
                    <td><input type="text" name="isms_sid" value="<?php echo esc_attr(get_option('isms_sid')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">API Domain</th>
                    <td><input type="text" name="isms_api_domain" value="<?php echo esc_attr(get_option('isms_api_domain')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Enable SMS Notifications</th>
                    <td>
                        <input type="checkbox" name="sms_notification_enabled" value="1" <?php checked(1, get_option('sms_notification_enabled'), true); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Purchase Message</th>
                    <td><textarea name="sms_purchase_message"><?php echo esc_textarea(get_option('sms_purchase_message')); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Cancel Message</th>
                    <td><textarea name="sms_cancel_message"><?php echo esc_textarea(get_option('sms_cancel_message')); ?></textarea></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Hold Message</th>
                    <td><textarea name="sms_hold_message"><?php echo esc_textarea(get_option('sms_hold_message')); ?></textarea></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Send SMS notification on order status change
add_action('woocommerce_order_status_changed', 'send_sms_on_order_status_change', 10, 3);
function send_sms_on_order_status_change($order_id, $old_status, $new_status) {
    // Check if SMS notifications are enabled
    if (!get_option('sms_notification_enabled')) {
        return;
    }

    $order = wc_get_order($order_id);
    $phone_number = $order->get_billing_phone();
    $user_name = $order->get_billing_first_name();

    if ($new_status == 'completed') {
        $message = get_option('sms_purchase_message', 'Thank you for your purchase!');
    } elseif ($new_status == 'cancelled') {
        $message = get_option('sms_cancel_message', 'Your order has been cancelled.');
    } elseif ($new_status == 'on-hold') {
        $message = get_option('sms_hold_message', 'Your order is on hold.');
    } else {
        return;
    }

    // Replace placeholders with actual values
    $message = replace_placeholders($message, $order_id, $user_name);

    if ($phone_number) {
        send_sms($phone_number, $message, uniqid());
    }
}


?>