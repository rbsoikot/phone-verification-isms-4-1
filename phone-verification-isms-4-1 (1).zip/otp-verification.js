jQuery(document).ready(function ($) {
    let attempts = 0;
    let resendDelay = 0;
    const delays = [30, 60, 120]; // Delay times in seconds for each retry

    $('#send-otp').on('click', function () {
        // If there's a delay, show it to the user
        if (resendDelay > 0) {
            $('#otp-error').text('Please wait ' + resendDelay + ' seconds before resending the OTP.');
            return;
        }

        const phoneNumber = $('#phone_number').val();
        if (!phoneNumber) {
            $('#otp-error').text('Please enter a phone number.');
            return;
        }

        $.ajax({
            url: ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'send_otp',
                phone_number: phoneNumber
            },
            success: function (response) {
                const data = JSON.parse(response);
                if (data.success) {
                    $('#otp-error').text('OTP sent successfully.');
                    
                    // Increase attempts count and set the resend delay
                    attempts++;
                    if (attempts <= delays.length) {
                        resendDelay = delays[attempts - 1];
                    } else {
                        resendDelay = delays[delays.length - 1];
                    }

                    // Start countdown timer
                    const countdown = setInterval(function () {
                        resendDelay--;
                        if (resendDelay <= 0) {
                            clearInterval(countdown);
                        }
                    }, 1000);
                } else {
                    $('#otp-error').text(data.message || 'Failed to send OTP.');
                }
            }
        });
    });
});
